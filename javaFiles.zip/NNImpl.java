// Student: Brennan Mowry
// Course: cs540

/**
 * The main class that handles the entire network
 * Has multiple attributes each with its own use
 * 
 */

import java.util.*;


public class NNImpl{
	public ArrayList<Node> inputNodes=null;//list of the input layer nodes.
	public ArrayList<Node> hiddenNodes=null;//list of the hidden layer nodes
	public ArrayList<Node> outputNodes=null;// list of the output layer nodes
	
	public ArrayList<Instance> trainingSet=null;//the training set
	
	Double learningRate=1.0; // variable to store the learning rate
	int maxEpoch=1; // variable to store the maximum number of epochs
	
	/**
 	* This constructor creates the nodes necessary for the neural network
 	* Also connects the nodes of different layers
 	* After calling the constructor the last node of both inputNodes and  
 	* hiddenNodes will be bias nodes. 
 	*/
	
	public NNImpl(ArrayList<Instance> trainingSet, int hiddenNodeCount, Double learningRate, int maxEpoch, Double [][]hiddenWeights, Double[][] outputWeights)
	{
		this.trainingSet=trainingSet;
		this.learningRate=learningRate;
		this.maxEpoch=maxEpoch;
		
		//input layer nodes
		inputNodes=new ArrayList<Node>();
		int inputNodeCount=trainingSet.get(0).attributes.size();
		int outputNodeCount=trainingSet.get(0).classValues.size();
		for(int i=0;i<inputNodeCount;i++)
		{
			Node node=new Node(0);
			inputNodes.add(node);
		}
		
		//bias node from input layer to hidden
		Node biasToHidden=new Node(1);
		inputNodes.add(biasToHidden);
		
		//hidden layer nodes
		hiddenNodes=new ArrayList<Node> ();
		for(int i=0;i<hiddenNodeCount;i++)
		{
			Node node=new Node(2);
			//Connecting hidden layer nodes with input layer nodes
			for(int j=0;j<inputNodes.size();j++)
			{
				NodeWeightPair nwp=new NodeWeightPair(inputNodes.get(j),hiddenWeights[i][j]);
				node.parents.add(nwp);
			}
			hiddenNodes.add(node);
		}
		
		//bias node from hidden layer to output
		Node biasToOutput=new Node(3);
		hiddenNodes.add(biasToOutput);
			
		//Output node layer
		outputNodes=new ArrayList<Node> ();
		for(int i=0;i<outputNodeCount;i++)
		{
			Node node=new Node(4);
			//Connecting output layer nodes with hidden layer nodes
			for(int j=0;j<hiddenNodes.size();j++)
			{
				NodeWeightPair nwp=new NodeWeightPair(hiddenNodes.get(j), outputWeights[i][j]);
				node.parents.add(nwp);
			}	
			outputNodes.add(node);
		}	
	}
	
	/**
	 * Get the output from the neural network for a single instance
	 * Return the idx with highest output values. For example if the outputs
	 * of the outputNodes are [0.1, 0.5, 0.2, 0.1, 0.1], it should return 1. If outputs
	 * of the outputNodes are [0.1, 0.5, 0.1, 0.5, 0.2], it should return 3. 
	 * The parameter is a single instance. 
	 */
	
	public int calculateOutputForInstance(Instance inst)
	{
		// initializes the input nodes to the values of the instance
		for (int i = 0; i < inst.attributes.size(); i++) {
			inputNodes.get(i).setInput(inst.attributes.get(i));
		}
		// update the output values of the hidden nodes
		for (int i = 0; i < hiddenNodes.size(); i++) {
			hiddenNodes.get(i).calculateOutput();
		}
		// update the output values of the output nodes
		for (int i = 0; i < outputNodes.size(); i++) {
			outputNodes.get(i).calculateOutput();
		}

		int index = 0;		// stores the index of the largest output
		double currMax = 0.0;   // holds the current maximum output
		
		for (int i = 0; i < outputNodes.size(); i++) {
			// find the largest output node
			if (currMax <= outputNodes.get(i).getOutput()) {
				currMax = outputNodes.get(i).getOutput();
				index = i;
			}
		}
		return index;
	}
	

	
	
	
	/**
	 * Train the neural networks with the given parameters
	 * 
	 * The parameters are stored as attributes of this class
	 */
	
	public void train()
	{
		for (int i = 0; i < maxEpoch; i++) {
			for (int j = 0; j < trainingSet.size(); j++) {
				// initializes the input nodes to the values of the instance
				for (int k = 0; k < inputNodes.size() - 1; k++) {
					inputNodes.get(k).setInput(trainingSet.get(j).attributes.get(k));
				}
				// update the output values of the hidden nodes
				for (int k = 0; k < hiddenNodes.size(); k++) {
					hiddenNodes.get(k).calculateOutput();
				}
				// update the output values of the output nodes
				for (int k = 0; k < outputNodes.size(); k++) {
					outputNodes.get(k).calculateOutput();
				}
				
				ArrayList<Double> errorK = new ArrayList<Double>();
				for (int k = 0; k < outputNodes.size(); k++) {
					errorK.add(trainingSet.get(j).classValues.get(k) - outputNodes.get(k).getOutput());
				}
				
				ArrayList<Double> deltaWJK = new ArrayList<Double>(); // hold the changes in the weights
																	  // between the hidden and the output nodes
				
				ArrayList<Double> deltaWIJ = new ArrayList<Double>(); // hold the changes in the weights
																	  // between the input and the hidden nodes
				
				// calculate the changes in the weights between the hidden and the output nodes
				for (int k = 0; k < hiddenNodes.size(); k++) {
					for (int m = 0; m < outputNodes.size(); m++) {
						deltaWJK.add(learningRate * hiddenNodes.get(k).getOutput() * errorK.get(m) * 
								outputNodes.get(m).getOutput() * (1 - outputNodes.get(m).getOutput()));
					}
				}
				
				// calculate the changes in the weights between the input and hidden nodes
				for (int k = 0; k < inputNodes.size(); k++) {
					for (int m = 0; m < hiddenNodes.size() - 1; m++) {
						double g1 = hiddenNodes.get(m).getOutput();
						double g1Prime = g1 * (1 - g1);
						double sum = 0;
						for (int n = 0; n < outputNodes.size(); n++) {
							double g2 = outputNodes.get(n).getOutput();
							double g2Prime = g2 * (1 - g2);
							sum += g2Prime * errorK.get(n) * outputNodes.get(n).parents.get(m).weight;
						}
						deltaWIJ.add(learningRate * inputNodes.get(k).getOutput() * g1Prime * sum);
					}
				}
				
				// update the weights between the input and hidden nodes
				for (int k = 0; k < inputNodes.size(); k++) {
					for (int m = 0; m < hiddenNodes.size() - 1; m++) {
						hiddenNodes.get(m).parents.get(k).weight += deltaWIJ.get(k * (hiddenNodes.size() - 1) + m);
					}
				}
				
				// update the weights between the hidden and output nodes
				for (int k = 0; k < hiddenNodes.size(); k++) {
					for (int m = 0; m < outputNodes.size(); m++) {
						outputNodes.get(m).parents.get(k).weight += deltaWJK.get(k * outputNodes.size() + m);
					}
				}
				
			}
		}
		
	}
}
